import { combineReducers, configureStore } from '@reduxjs/toolkit';
import themeConfigSlice from '../features/themeConfigSlice'
import authReducer from '../features/auth/authSlice';


export  const store = configureStore({
    reducer: {
        themeConfig: themeConfigSlice,
        auth: authReducer
    }
});

export type IRootState = ReturnType<typeof store.getState>;
