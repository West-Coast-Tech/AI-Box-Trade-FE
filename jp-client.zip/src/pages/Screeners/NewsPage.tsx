import { Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { setPageTitle } from '../../redux/features/themeConfigSlice';
import API from '../../utils/API';
import { INews } from '../../redux/types';

const NewsPage = () => {
    const dispatch = useDispatch();
    const [news, setNews] = useState<INews[]>([]);
    const [loading, setLoading] = useState<boolean>(false);
    const [error, setError] = useState<string>('');

    useEffect(() => {
        dispatch(setPageTitle('News Page'));
    }, [dispatch]);

    useEffect(() => {
        const fetchNews = async () => {
            setLoading(true);
            try {
                const response = await API.getNews();
                setNews(response.data);
            } catch (err: any) {
                console.error('Error fetching news:', err);
                setError('Failed to fetch news data.');
            } finally {
                setLoading(false);
            }
        };

        fetchNews();
    }, []);

    const formatTime = (timeInMillis: string | number): string => {
        const date = new Date(Number(timeInMillis));
        return date.toDateString();
    };
    return (
        <div className="container mx-auto mt-8">
            <h2 className="text-2xl font-semibold text-center mb-6">Latest News</h2>
            {loading && <p className="text-center">Loading...</p>}
            {error && <p className="text-center text-red-500">{error}</p>}

            {!loading && !error && (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                    {news.map((item, index) => (
                        <div key={index} className="border border-gray-300 dark:border-gray-700 rounded-lg overflow-hidden shadow-md">
                            <img src={item.img} alt={item.title} className="w-full h-40 object-cover" />
                            <div className="p-4">
                                <h3 className="font-semibold text-lg mb-2">{item.title}</h3>
                                <p className="text-gray-600 dark:text-gray-400 mb-4">{item.text}</p>
                                <div className="text-sm text-gray-500">
                                    <p>Source: {item.source}</p>
                                    <p>{formatTime(item.time)}</p>
                                    <p className="italic">{item.ago}</p>
                                </div>
                                <div className="mt-3">
                                    <Link to={item.url} className="inline-block bg-primary text-white px-4 py-2 rounded hover:bg-primary-dark transition" target="_blank" rel="noopener noreferrer">
                                        Read More
                                    </Link>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default NewsPage;
